//
//  TestPreviewProvider.swift
//  TestSwiftPreview
//
//  Created by 程鹏 on 2024/11/15.
//

import Foundation
import UIKit
//import yychannelcomponent
//import yychannelbase
//import yybaseservice
import yybaseapisdk
import SwiftUI

@objc public class TestView: UIView {
    @objc public class func show(view: UIView) {
//        let titleAttr = NSAttributedString(string: "画面内容位置不足", attributes: [
//            .foregroundColor: UIColor.red,
//            .font: UIFont.boldSystemFont(ofSize: 20)
//        ])
//        let message = String(format: "因画面位置不足，礼物点单将自动适配、点击“确定”将隐藏最后%@条点单内容。是否确认开启礼物点单？", "\(1)")
//
//        let messageAttri = NSMutableAttributedString(string: message, attributes: [
//            .foregroundColor: UIColor.blue,
//            .font: UIFont.systemFont(ofSize: 16)
//        ])
//
//        let highlightStr = String(format: "隐藏最后%@条点单内容", "\(1)")
//        if let range = message.range(of: highlightStr) {
//            messageAttri.addAttribute(.foregroundColor, value: UIColor.red, range: NSRange(range, in: message))
//        }
//
//        let alertView = YYAlertView(attributedTitle: titleAttr, attributedMessage: messageAttri)
//        alertView.backgroundColor = .yellow
//        alertView.show(in: view)
    }
}

@available(iOS 17, *)
#Preview {
    {
        let viewcontroller = UIViewController()
        viewcontroller.view.backgroundColor = .lightGray
        
        let titleAttr = NSAttributedString(string: "画面内容位置不足", attributes: [
            .foregroundColor: UIColor.red,
            .font: UIFont.boldSystemFont(ofSize: 20)
        ])
        let message = String(format: "因画面位置不足，礼物点单将自动适配、点击“确定”将隐藏最后%@条点单内容。是否确认开启礼物点单？", "\(1)")

        let messageAttri = NSMutableAttributedString(string: message, attributes: [
            .foregroundColor: UIColor.blue,
            .font: UIFont.systemFont(ofSize: 16)
        ])

        let highlightStr = String(format: "隐藏最后%@条点单内容", "\(1)")
        if let range = message.range(of: highlightStr) {
            messageAttri.addAttribute(.foregroundColor, value: UIColor.red, range: NSRange(range, in: message))
        }

        let alertView = YYAlertView(attributedTitle: titleAttr, attributedMessage: messageAttri)
        alertView.backgroundColor = .yellow
        alertView.show(in: viewcontroller.view)
        
        return viewcontroller
    }()
}
